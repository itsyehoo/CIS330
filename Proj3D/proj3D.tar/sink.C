#include <sink.h>

void sink::SetInput(Image *input1)
{
    imgPtr1 = input1;
}

void sink::SetInput2(Image *input2)
{
    imgPtr2 = input2;
}

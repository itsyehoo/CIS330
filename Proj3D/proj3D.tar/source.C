
#include <source.h>

Image * source::GetOutput()
{
    return &img;
}
